--
-- Tracer -- Helper for addon authors to figure out what's going
-- on with their code in the wild.
-- 
-- Copyright (c) 2005 Steve Kehlet
--

tracer = {}
tracer.defaultSize = 500
tracerData = {}
tracerData.version = "1.0"
tracerData.root = {}
local myData
local mySize

function tracer.OnLoad()
   this:RegisterEvent("PLAYER_ENTERING_WORLD")
   tracer.p("Tracer v"..tracerData.version.." loaded.")
end

function tracer.OnEvent(event)
   if (event == "PLAYER_ENTERING_WORLD") then
      local realmName = GetRealmName()
      local playerName = UnitName("player")
      if (not tracerData.root[realmName]) then
         tracerData.root[realmName] = {}
      end
      if (not tracerData.root[realmName][playerName]) then
         tracerData.root[realmName][playerName] = {}
      end
      if (not tracerData.root[realmName][playerName][data]) then
         tracerData.root[realmName][playerName]["data"] = {}
      end
      if (not tracerData.root[realmName][playerName][size]) then
         tracerData.root[realmName][playerName]["size"] = {}
      end

      -- convenient references
      myData = tracerData.root[realmName][playerName]["data"]
      mySize = tracerData.root[realmName][playerName]["size"]
   end
end

function tracer.Clear(label)
   if (myData[label]) then
      myData[label] = {}
   end
end

function tracer._resizeData(label)
   if (myData[label]) then
      local size = table.getn(myData[label])
      if (size > mySize[label]) then
         local difference = size - mySize[label]
         local i
         for i = 1, difference do
            table.remove(myData[label], 1)
         end
      end
   end
end

function tracer.Size(label, size)
   mySize[label] = size
   tracer._resizeData(label)
end

function tracer.Log(label, msg)
   if (not label or label == "" or not msg or msg == "") then
      tracer.p("usage: tracer.Log(label, msg)")
      return
   end
   if (not myData[label]) then
      myData[label] = {}
   end
   if (not mySize[label]) then
      mySize[label] = tracer.defaultSize
   end
   table.insert(myData[label], msg)
   tracer._resizeData(label)
end

function tracer.Dump(label)
   if (not label or label == "") then
      tracer.p("usage: tracer.Dump(label)")
      return
   end
   if (myData[label]) then
      for idx, val in myData[label] do
         tracer.p(idx.."> "..val)
      end
   end
end


-- Utilities

function tracer.p(msg)
   DEFAULT_CHAT_FRAME:AddMessage(msg,.6,.5,0)
end
