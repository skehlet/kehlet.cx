--
-- SmartBandage -- Find and use the right bandage for the job.
-- 
-- Usage: Put the following in a macro:
--
-- /script SmartBandage()
-- 
-- or /script SmartBandage(true) if you want it to retarget your last enemy
--
-- Copyright (c) 2005 Steve Kehlet
--

sBandage = {}
sBandage.version = "1.2b3"
sBandage.debug = false
sBandage.trace = true

sBandage.bandages = {
   {"Linen Bandage",                   66},
   {"Heavy Linen Bandage",             114},
   {"Wool Bandage",                    161},
   {"Heavy Wool Bandage",              301},
   {"Silk Bandage",                    400},
   {"Heavy Silk Bandage",              640},
   {"Mageweave Bandage",               800},
   {"Heavy Mageweave Bandage",         1104},
   {"Runecloth Bandage",               1360},
   {"Heavy Runecloth Bandage",         2000},
   {"Alterac Heavy Runecloth Bandage", 2000, "Alterac Valley"},
   {"Arathi Basin Silk Bandage",       640,  "Arathi Basin"},
   {"Defiler's Silk Bandage",          640,  "Arathi Basin"},
   {"Highlander's Silk Bandage",       640,  "Arathi Basin"},
   {"Arathi Basin Mageweave Bandage",  1104, "Arathi Basin"},
   {"Defiler's Mageweave Bandage",     1104, "Arathi Basin"},
   {"Highlander's Mageweave Bandage",  1104, "Arathi Basin"},
   {"Arathi Basin Runecloth Bandage",  2000, "Arathi Basin"},
   {"Defiler's Runecloth Bandage",     2000, "Arathi Basin"},
   {"Highlander's Runecloth Bandage",  2000, "Arathi Basin"},
   {"Warsong Gulch Silk Bandage",      640,  "Warsong Gulch"},
   {"Warsong Gulch Mageweave Bandage", 1104, "Warsong Gulch"},
   {"Warsong Gulch Runecloth Bandage", 2000, "Warsong Gulch"},
}

function sBandage.OnLoad()
   sBandage.p("SmartBandage v"..sBandage.version.." loaded.")
end

function sBandage.FindBandages()
   local bag, slot, link, itemName, idx, bInfo

   sBandage.d("## SmartBandage: finding bandages")

   for idx, bInfo in sBandage.bandages do
      -- reset everything
      bInfo[4] = {}
   end

   for bag = 4, 0, -1 do
      for slot = 1, GetContainerNumSlots(bag) do
         link = GetContainerItemLink(bag, slot)
         if (link) then
            itemName = sBandage.NameFromLink(link)
            for idx, bInfo in sBandage.bandages do
               if (itemName == bInfo[1]) then
                  -- found a bandage
                  sBandage.d("## SmartBandage: found "..itemName.." at "..bag..", "..slot)
                  table.insert(bInfo[4], {bag, slot})
                  break
               end
            end
         end
      end
   end
end

function sBandage.ChooseBandage(need, bgMapName)
   local found = nil
   local bestBandage = nil
   
   local idx, bInfo
   for idx, bInfo in sBandage.bandages do
      if (table.getn(bInfo[4]) > 0) then
         if (bgMapName == bInfo[3]) then -- works properly when bgMapName is nil too
            bestBandage = idx
            if (bInfo[2] >= need) then
               found = idx
               sBandage.d("## SmartBandage: "..sBandage.bandages[found][1].." will do the job")
               break
            end
         end
      end
   end
   if (not found) then
      -- none found that are good enough, just use the best we've got (if anything)
      if (not bestBandage) then
         sBandage.d("## SmartBandage: no bandage found this pass")
         return false
      end
      found = bestBandage
      sBandage.d("## SmartBandage: "..sBandage.bandages[found][1].." will have to do")
   end

   return found
end

function sBandage.TargetIsPartymate()
   if (UnitInParty("target")) then
      return true
   end
   if (UnitInRaid("target")) then
      return true
   end

   -- argh, UnitInParty() and UnitInRaid() don't return true for pets.
   -- painstakingly poll party or raid group members' pets as necessary

   if (GetNumPartyMembers() > 0) then
      for i = 1, 4 do
         if (UnitIsUnit("target", "partypet"..i)) then
            return true
         end
      end
   end

   if (GetNumRaidMembers() > 0) then
      for i = 1, 40 do
         if (UnitIsUnit("target", "raidpet"..i)) then
            return true
         end
      end
   end

   return false
end

function sBandage.SmartBandage(retargetLastEnemy)
   if (not UnitIsFriend("player","target")) then
      TargetUnit("player")
   end
   
   if (not sBandage.TargetIsPartymate()) then
      sBandage.p("## SmartBandage: target is not in party or raid group")
      return false
   end

   -- target health is 80% if out of combat (we're regen'ing), 100% if we're in
   local targetHealthPct = 80
   if (PlayerFrame.inCombat) then
      targetHealthPct = 100
   end

   local need = (UnitHealthMax("target") * targetHealthPct/100) - UnitHealth("target")

   if (need <= 0) then
      sBandage.p("## SmartBandage: not enough need")
      return false
   end

   sBandage.FindBandages()

   local found = false
   local status, mapName, instanceID = GetBattlefieldStatus()
   if (status == "active") then
      sBandage.d("SmartBandage: you're in batteground: "..mapName)
      -- in a Battleground, try to use BG bandages first
      found = sBandage.ChooseBandage(need, mapName)
      if (not found) then
         -- but fall back to regular if none found
         found = sBandage.ChooseBandage(need)
      end
   else
      -- regular play
      found = sBandage.ChooseBandage(need)
   end

   if (found) then
      sBandage.p("## SmartBandage: Using "..sBandage.bandages[found][1]..
                 " ("..sBandage.bandages[found][2]..") on "..UnitName("target"))
      local slotInfo = sBandage.bandages[found][4][1]
      local bag, slot = slotInfo[1], slotInfo[2]
      UseContainerItem(bag, slot)

   else
      sBandage.p("## SmartBandage: couldn't find any bandages!")
   end

   if (retargetLastEnemy) then
      TargetLastEnemy()
   end
end

SmartBandage = sBandage.SmartBandage


-- Utilities

function sBandage.traceLog(msg)
   if (sBandage.trace and tracer) then
      tracer.Log("SmartBandage", msg)
   end
end

function sBandage.p(msg)
   DEFAULT_CHAT_FRAME:AddMessage(msg,.8,.4,0)
   sBandage.traceLog(msg)
end

function sBandage.d(msg)
   if (sBandage.debug) then
      DEFAULT_CHAT_FRAME:AddMessage(msg,.8,.4,0)
   end
   sBandage.traceLog(msg)
end

function sBandage.NameFromLink(link)
  local name
  if (not link) then
    return ""
  end
  for name in string.gfind(link, ".c%x+.Hitem:%d+:%d+:%d+:%d+.h%[(.-)%].h.r") do
    return name
  end
  return nil
end
