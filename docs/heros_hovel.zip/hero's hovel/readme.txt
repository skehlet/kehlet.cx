Hero's Hovel
by Steve Kehlet <steven@kehlet.cx>
Jan 22, 2004

Every hero needs a hovel, err home, to call his or her own.  Hero's Hovel can be found nestled in a quiet mountain range just west of Pelagiad.  

Updates for v1.1:
- Spruced up a number of things around the outside.
- Gave Laila some more things to talk about.  She'll now get you coffee (with or without moonsugar) while you hang out.
- Fixed a number of issues Quatloos pointed out, including removing the bogus door in the backyard, moving the books to an easier spot to get to, etc, giving Laila more room to walk, etc.
- Spruced up the downstairs and cellar area, adding weapons, a practice mat, more storage, etc.


Readme from v1.0:

Highlights of your new home include:

- a personal assistant, Laila, to make your stay even more pleasant.
- a vast serias of magic portals with one-way destinations to over 50 key locations across Vvardenfell.
- a magic ring with which to return to your hovel at any time (get it from Laila).
- a splendid view of Pelagiad and Lake Amaya to the East.
- a warm, homey retreat in which to rest and relax.
- ample storage in the cellar downstairs to store your stuff.

Also of note:

- this mod was written to work with Marcel Hesselbarth's Multiple Teleport mod.
- significant effort was taken to keep this mod CLEAN (thanks TESPCD).

Have fun!

Steve
